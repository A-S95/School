# potencias de 3 entre 1 e 1000
potencia = 1
expoente = 0

while potencia <= 1000:
    print(f"3^{expoente} = {potencia}")
    expoente += 1
    potencia = 3 ** expoente