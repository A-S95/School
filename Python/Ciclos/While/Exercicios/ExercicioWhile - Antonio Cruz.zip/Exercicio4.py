# Escreva um  programa que apresente os numeros pares entre 0 e 100

num = 2
contador = 1

while contador < 51:
    resultado = num * contador
    print(resultado)
    contador += 1
