#Multiplos de 4 entre 0 e 100
num = 0

while num <= 100:
    if num % 4 == 0:
        print(num)

    num += 1