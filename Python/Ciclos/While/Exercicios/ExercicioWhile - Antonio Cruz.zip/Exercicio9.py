#Potencias de 2 entre 1024 e 1
contador = 1024

while contador >= 1:
    print("Potencia de 2: ", contador)
    contador /= 2