# Despesas mercearia
total_despesas = 0
contador = 1

while True:
    despesa = float(input(f"Insira o valor da despesa {contador} (ou 0 para terminar): "))
    
    if despesa == 0:
        break
    
    total_despesas += despesa
    contador += 1

print(f"\nTotal de despesas inseridas: {contador - 1}")
print(f"Total gasto na mercearia: {total_despesas:.2f} €")

if total_despesas > 100:
    print("Atenção: As despesas ultrapassaram 100 €!")