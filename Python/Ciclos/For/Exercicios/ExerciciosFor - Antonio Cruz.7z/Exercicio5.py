#Multiplos de 4 entre 0 e 100

for i in range(0, 101):
    if i % 4 == 0:
        print(i)
