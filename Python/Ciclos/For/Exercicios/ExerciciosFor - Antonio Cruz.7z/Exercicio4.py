# Numeros pares entre 0 e 100

for num in range(0, 101, 2):
    print(num)