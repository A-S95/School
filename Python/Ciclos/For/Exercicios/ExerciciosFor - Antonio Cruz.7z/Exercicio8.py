# potencias de 3 entre 1 e 1000

for i in range(1, 10):
        print(f"{i}^3 = {i**3}")
