#potencias de 1/2

for i in range(1, 11):
    print(f"2 elevado a {i} é igual a: {2 ** i}")