#pontencias de 2 entre 1024 e 1

for i in range(10, -1, -1):
    print(f"2^{i} = {2**i}")