# Tabuada 

tabuada = int(input("Digite um número para ver a tabuada: "))

for i in range(1, 11):
    print(f"{tabuada} x {i} = {tabuada * i}")